/* voxelize points, lines, and triangles into sparse voxels using efficient algorithms of DDA voxelization
    adapted from: https://github.dev/MIERUNE/dda-voxelize-rs/blob/main/src/voxelize.rs
 */

#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <ranges>
#include <set>
#include <type_traits>
#include <unordered_map>
#include <vector>

#include <omp.h>
#include <tbb/concurrent_hash_map.h>

// // // // // // // // // // // // // // // // // // // // // //

class Voxelizer {
public:
    using Vec3d = std::array<double, 3>;
    using Vec3i = std::array<int, 3>;

private:
    struct Vec3iHash {
        static size_t hash(const Vec3i &v) {
            size_t x = std::hash<int>{}(v[0]);
            size_t y = std::hash<int>{}(v[1]);
            size_t z = std::hash<int>{}(v[2]);

            constexpr size_t golden_ratio = sizeof(size_t) == 8 ? 0x9e3779b97f4a7c15ull : 0x9e3779b9u;

            size_t hash = x;
            hash ^= y + golden_ratio + (hash << 6) + (hash >> 2);
            hash ^= z + golden_ratio + (hash << 6) + (hash >> 2);

            hash ^= hash >> 30;
            hash *= golden_ratio;
            hash ^= hash >> 27;
            hash *= golden_ratio;
            hash ^= hash >> 31;

            return hash;
        }

        static bool equal(const Vec3i &a, const Vec3i &b) { return a == b; }
    };

    inline double make_safe(double x) {
        constexpr double eps = 1e-10;
        if (std::abs(x) < eps) {
            return x >= 0.0 ? eps : -eps;
        }
        return x;
    }

    template <typename T>
        requires std::is_arithmetic_v<T>
    inline std::array<T, 3> add(const std::array<T, 3> &a, const std::array<T, 3> &b) {
        return {a[0] + b[0], a[1] + b[1], a[2] + b[2]};
    }

    template <typename T>
        requires std::is_arithmetic_v<T>
    inline std::array<T, 3> sub(const std::array<T, 3> &a, const std::array<T, 3> &b) {
        return {a[0] - b[0], a[1] - b[1], a[2] - b[2]};
    }

    template <typename T>
        requires std::is_arithmetic_v<T>
    inline std::array<T, 3> mul(const std::array<T, 3> &a, const std::array<T, 3> &b) {
        return {a[0] * b[0], a[1] * b[1], a[2] * b[2]};
    }

    template <typename T>
        requires std::is_arithmetic_v<T>
    inline std::array<T, 3> div(const std::array<T, 3> &a, const std::array<T, 3> &b) {
        return {a[0] / make_safe(b[0]), a[1] / make_safe(b[1]), a[2] / make_safe(b[2])};
    }

    template <typename T>
        requires std::is_arithmetic_v<T>
    inline std::array<T, 3> mul(const std::array<T, 3> &a, T b) {
        return {a[0] * b, a[1] * b, a[2] * b};
    }

    template <typename T>
        requires std::is_arithmetic_v<T>
    inline std::array<T, 3> div(const std::array<T, 3> &a, T b) {
        b = make_safe(b);
        return {a[0] / b, a[1] / b, a[2] / b};
    }

    template <typename D, typename T>
        requires std::is_arithmetic_v<D>
    inline std::array<D, 3> to(const T &a) {
        return {static_cast<D>(a[0]), static_cast<D>(a[1]), static_cast<D>(a[2])};
    }

    template <typename T>
        requires std::is_arithmetic_v<T>
    inline int sgn(const T &val) {
        return (T(0) < val) - (val < T(0));
    }

    template <typename T>
        requires std::is_arithmetic_v<T>
    inline Vec3i sgn(const std::array<T, 3> &a) {
        return {sgn(a[0]), sgn(a[1]), sgn(a[2])};
    };

    template <typename T>
        requires std::is_arithmetic_v<T>
    inline std::array<T, 3> abs(const std::array<T, 3> &a) {
        return {std::abs(a[0]), std::abs(a[1]), std::abs(a[2])};
    };

    inline Vec3d min(const Vec3d &a, const Vec3d &b) {
        return {std::min(a[0], b[0]), std::min(a[1], b[1]), std::min(a[2], b[2])};
    }

    inline Vec3d max(const Vec3d &a, const Vec3d &b) {
        return {std::max(a[0], b[0]), std::max(a[1], b[1]), std::max(a[2], b[2])};
    }

    inline int find_max_abs_axis(const Vec3d &v) {
        auto it = std::ranges::max_element(std::views::iota(0, 3), {}, [&](int i) { return std::abs(v[i]); });
        return *it;
    }

    inline int determine_sweep_axis(const Vec3d &v0, const Vec3d &v1, const Vec3d &v2, int normal_axis) {
        const Vec3d min_point = min(min(v0, v1), v2);
        const Vec3d max_point = max(max(v0, v1), v2);
        const Vec3d box_size = sub(max_point, min_point);

        constexpr std::array<std::pair<int, int>, 3> axis_pairs = {
            std::pair{1, 2}, // normal_axis = 0  -->  compare Y vs Z
            std::pair{2, 0}, // normal_axis = 1  -->  compare Z vs X
            std::pair{0, 1}  // normal_axis = 2  -->  compare X vs Y
        };

        const auto [a, b] = axis_pairs[normal_axis];
        return box_size[a] >= box_size[b] ? a : b;
    }

    inline double norm2(const Vec3d &a) { return a[0] * a[0] + a[1] * a[1] + a[2] * a[2]; };

    inline Vec3d normalize(const Vec3d &a) {
        double length = norm2(a);
        if (length == 0.0)
            return {0.0, 0.0, 0.0};
        length = std::sqrt(length);
        return div(a, length);
    };

    inline Vec3d cross(const Vec3d &a, const Vec3d &b) {
        return {a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    };

    // // // // // // // // // // // // // // // // // // // // // //

public:
    const double voxel_size;

    // use multi-threads for voxelization, if the number of simplices is larger than this threshold
    const int parallel_threshold;

    // ensure thread-safe access to the sparse grid
    tbb::concurrent_hash_map<Vec3i, std::set<int>, Vec3iHash> sparse_grid; // voxel location  -->  simplex indices

    // // // // // // // // // // // // // // // // // // // // // //

    Voxelizer(double voxel_size, int parallel_threshold)
        : voxel_size(voxel_size), parallel_threshold(parallel_threshold) {}

    // // // // // // // // // // // // // // // // // // // // // //

    inline int discretize(double x) const {
        // use rounding to the nearest integer
        return std::floor(x + 0.5);
    }

    inline Vec3i discretize(const Vec3d &x) const { return {discretize(x[0]), discretize(x[1]), discretize(x[2])}; }

    // // // // // // // // // // // // // // // // // // // // // //

    void put_voxel(const Vec3i &voxel, int simx_idx) {

        // the same as:  sparse_grid[voxel].push_back(simx_idx);
        decltype(sparse_grid)::accessor acc;
        sparse_grid.insert(acc, voxel); // insert or find the key
        acc->second.insert(simx_idx);   // modify safely
    }

    // // // // // // // // // // // // // // // // // // // // // //

    // to voxelize one single point
    void for_point(int simx_idx, const Vec3d &_point) {
        Vec3i voxel = discretize(div(_point, voxel_size));
        put_voxel(voxel, simx_idx);
    }

    // to voxelize one line segment
    template <bool divided = true> void for_line(int simx_idx, const Vec3d &_start, const Vec3d &_end) {

        Vec3d start, end;
        if constexpr (divided) {
            start = div(_start, voxel_size);
            end = div(_end, voxel_size);
        } else {
            start = _start;
            end = _end;
        }

        Vec3i current_voxel = discretize(start);
        Vec3i last_voxel = discretize(end);

        // only occupy one voxel
        if (current_voxel == last_voxel) {
            put_voxel(current_voxel, simx_idx);
            return;
        }

        Vec3d difference = sub(end, start);
        Vec3i step = sgn(difference);

        Vec3d next_voxel_boundary = add(mul(to<double>(step), 0.5), to<double>(current_voxel));
        Vec3d tmax = div(sub(next_voxel_boundary, start), difference);
        Vec3d tdelta = div(to<double>(step), difference);

        for (int i : {0, 1, 2}) {
            // do not attempt to increment along the dimension where the step size is zero
            if (std::abs(difference[i]) < 1e-10) {
                tmax[i] = std::numeric_limits<double>::infinity();
            }
        }

        Vec3d dir = normalize(difference);
        double distance = std::sqrt(norm2(difference));
        Vec3d xyz_inv = div(abs(dir), distance);

        put_voxel(current_voxel, simx_idx);
        put_voxel(last_voxel, simx_idx);

        double t = 0.0;
        while (current_voxel != last_voxel && t < 1.0) {
            put_voxel(current_voxel, simx_idx);

            // find the axis with the minimum tmax
            int argmin_tmax =
                *std::ranges::min_element(std::views::iota(0, 3), [&](int i, int j) { return tmax[i] < tmax[j]; });

            current_voxel[argmin_tmax] += step[argmin_tmax];
            tmax[argmin_tmax] += tdelta[argmin_tmax];
            t += xyz_inv[argmin_tmax];
        }

        if (t <= 1.0) {
            put_voxel(current_voxel, simx_idx);
        }
    }

    // to voxelize one triangle
    void for_triangle(int simx_idx, const Vec3d &_v0, const Vec3d &_v1, const Vec3d &_v2) {

        Vec3d v0 = div(_v0, voxel_size);
        Vec3d v1 = div(_v1, voxel_size);
        Vec3d v2 = div(_v2, voxel_size);

        Vec3d normal = cross(sub(v1, v0), sub(v2, v0));
        double normal_length = std::sqrt(norm2(normal));
        if (std::isnan(normal_length) || normal_length == 0.0) {
            // draw lines when the triangle is colinear, or degenerated
            for_line<false>(simx_idx, v0, v1);
            for_line<false>(simx_idx, v1, v2);
            for_line<false>(simx_idx, v2, v0);
            return;
        }
        normal = div(normal, normal_length);

        int normal_axis = find_max_abs_axis(normal);

        int sweep_axis = determine_sweep_axis(v0, v1, v2, normal_axis);

        if (v0[sweep_axis] > v1[sweep_axis]) {
            std::swap(v0, v1);
        }
        if (v1[sweep_axis] > v2[sweep_axis]) {
            std::swap(v1, v2);
        }
        if (v0[sweep_axis] > v1[sweep_axis]) {
            std::swap(v0, v1);
        }

        assert(v1[sweep_axis] >= v0[sweep_axis]);

        Vec3d v01 = sub(v1, v0);
        Vec3d v02 = sub(v2, v0);
        Vec3d v12 = sub(v2, v1);

        Vec3d end_step = div(v02, v2[sweep_axis] - v0[sweep_axis]);
        Vec3d end_pos = add(v0, mul(end_step, 1.0 - v0[sweep_axis] + std::floor(v0[sweep_axis])));

        Vec3d start_step1 = div(v01, v1[sweep_axis] - v0[sweep_axis]);
        Vec3d start_step2 = div(v12, v2[sweep_axis] - v1[sweep_axis]);

        double to_next_line = 1.0 - v0[sweep_axis] + std::floor(v0[sweep_axis]);
        Vec3d start_pos = add(v0, mul(start_step1, to_next_line));

        if (std::abs(v1[sweep_axis] - v0[sweep_axis]) >= 1e-10) {
            // underjet
            if (to_next_line > 0.5) {
                double d = to_next_line - 0.5;
                Vec3d s = add(v0, mul(v01, d));
                Vec3d e = add(v0, mul(v02, d));
                s[sweep_axis] -= 0.5;
                e[sweep_axis] -= 0.5;
                for_line<false>(simx_idx, s, e);
            };

            // Start position is on the first edge
            while (start_pos[sweep_axis] <= v1[sweep_axis]) {
                for_line<false>(simx_idx, start_pos, end_pos);
                start_pos = add(start_pos, start_step1);
                end_pos = add(end_pos, end_step);
            }

            // Switch to the second edge
            double end_vertex_y = v1[sweep_axis] - start_pos[sweep_axis];
            start_pos = add(start_pos, mul(sub(start_step1, start_step2), end_vertex_y));

        } else {
            // Switch to the second edge
            start_pos = add(v1, mul(start_step2, 1.0 - v1[sweep_axis] + std::floor(v1[sweep_axis])));
        }

        if (std::abs(v2[sweep_axis] - v1[sweep_axis]) >= 1e-10) {
            // Start position is on the second edge
            while (end_pos[sweep_axis] <= v2[sweep_axis]) {
                for_line<false>(simx_idx, start_pos, end_pos);
                start_pos = add(start_pos, start_step2);
                end_pos = add(end_pos, end_step);
            }

            // overjet
            if (end_pos[sweep_axis] - 0.5 < v2[sweep_axis] && end_pos[sweep_axis] - 0.5 > v1[sweep_axis]) {
                start_pos = sub(start_pos, mul(start_step2, 0.5));
                end_pos = sub(end_pos, mul(end_step, 0.5));

                start_pos[sweep_axis] += 0.5;
                end_pos[sweep_axis] += 0.5;

                for_line<false>(simx_idx, start_pos, end_pos);
            }
        }
    }

    // // // // // // // // // // // // // // // // // // // // // //

    void voxelize(const std::vector<std::array<Vec3d, 3>> &triangles, const std::vector<int> &indices) {
        assert(triangles.size() == indices.size());

#pragma omp parallel if (triangles.size() >= parallel_threshold)
        {
#pragma omp for
            for (int i = 0; i < triangles.size(); ++i) {
                for_triangle(indices[i], triangles[i][0], triangles[i][1], triangles[i][2]);
            }
        }
    }

    void voxelize(const std::vector<std::array<Vec3d, 2>> &lines, const std::vector<int> &indices) {
        assert(lines.size() == indices.size());

#pragma omp parallel if (lines.size() >= parallel_threshold)
        {
#pragma omp for
            for (int i = 0; i < lines.size(); ++i) {
                for_line(indices[i], lines[i][0], lines[i][1]);
            }
        }
    }

    void voxelize(const std::vector<Vec3d> &points, const std::vector<int> &indices) {
        assert(points.size() == indices.size());

#pragma omp parallel if (points.size() >= parallel_threshold)
        {
#pragma omp for
            for (int i = 0; i < points.size(); ++i) {
                for_point(indices[i], points[i]);
            }
        }
    }

    // // // // // // // // // // // // // // // // // // // // // //

    auto read() {
        std::vector<Vec3i> voxels_unique; // shape == [num_unique_sparse_voxels, 3]   integer values        unique
                                          // sparse voxel coordinates
        std::vector<int>
            simx_indices; // shape == [sum{num_simx_in_voxel_i}, ]       maximum num_simx-1    to index simplices
        std::vector<int>
            voxel_indices; // shape == [sum{num_simx_in_voxel_i}, ]      maximum num_voxel-1   to index voxels
        // out = segment_coo(feat_simx[simx_indices], voxel_indices, reduce="sum")
        // out : scatter (add) simplex features into sparse voxels, shape == [num_unique_sparse_voxels, dim_feat]

        int idx_voxel = 0;
        for (const auto &[voxel, indices] : sparse_grid) {
            voxels_unique.push_back(voxel);

            simx_indices.insert(simx_indices.end(), indices.begin(), indices.end());

            std::vector<int> indices_copy(indices.size(), idx_voxel++);
            voxel_indices.insert(voxel_indices.end(), indices_copy.begin(), indices_copy.end());
        }

        return std::make_tuple(voxels_unique, simx_indices, voxel_indices);
    }

    void clear() { sparse_grid.clear(); }
};
