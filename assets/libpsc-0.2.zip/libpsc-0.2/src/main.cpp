#include <algorithm>
#include <array>
#include <cassert>
#include <cmath>
#include <fstream>
#include <iostream>
#include <map>
#include <optional>
#include <sstream>
#include <string>
#include <tuple>
#include <vector>

#include "G3dOGL/SimplicialComplex.h"
#include "G3dOGL/SplitRecord.h"

#include "voxelize.hpp"

#include <pybind11/pybind11.h>
#include <pybind11/stl.h>

namespace py = pybind11;

// // // // // // // // // // // // // // // // // // // // // // // // // //
// // // // // // // // // // // // // // // // // // // // // // // // // //

using Array3 = std::array<float, 3>;

struct PSC {
    hh::SimplicialComplex Kmesh;

    // initialized from a single point
    PSC(const Array3 &init_p) {
        std::stringstream ss;
        ss << "Simplex 0 1 " << init_p[0] << " " << init_p[1] << " " << init_p[2] << "\n";
        Kmesh.read(ss);
    }

    // initialized from verts, edges and faces
    PSC(
        // note :
        //   "edges" and "faces" are to index "verts"
        //   we will automatically add some edges that are not in the variable "edges" but can be derived from "faces"
        std::vector<std::array<float, 3>> verts, // vertex position
        std::vector<std::array<int, 2>> edges,   // edge connectivity
        std::vector<std::array<int, 3>> faces,   // face connectivity
        // note : setting the weighting factor to:
        //   negative will disable volume weighting
        //   positive will enable volume weighting, the volume is further scaled by this factor
        //   zero     will zero out the quadric, so that it will have no effect
        std::vector<float> weighting_v, std::vector<float> weighting_e, std::vector<float> weighting_f,
        // the penalty for topological changes
        //   set to a high value will discourage topological changes
        //   and postpone collapses that change the topology
        float weighting_topo) {

        // set the penalty for topological changes
        Kmesh._weighting_topo = weighting_topo;

        // sort edges and faces
        for (auto &e : edges) {
            if (e[0] > e[1]) {
                std::swap(e[0], e[1]);
            }
        }
        for (auto &f : faces) {
            std::sort(f.begin(), f.end());
        }

        // prepare as a string so that we can directly use the "read()" function
        std::stringstream ss;

        // add vertices
        for (int i = 0; i < verts.size(); ++i) {
            const auto &v = verts[i];
            ss << "Simplex 0 " << i + 1 << " " << v[0] << " " << v[1] << " " << v[2] << "\n";
        }

        // derive those edges that are in the faces but not in the variable "edges"
        std::map<std::array<int, 2>, int> edges_all; // vertex pairs --> idx_e

        // firstly, insert original edges
        int idx_e = 0;
        for (auto e : edges) {
            assertx(e[0] < e[1]);
            auto [_, ok] = edges_all.insert({e, idx_e++});
            assertx(ok); // should not be duplicated
        }

        // secondly, insert missing edges
        for (const auto &f : faces) {
            for (auto [i, j] : {std::make_pair(0, 1), std::make_pair(1, 2), std::make_pair(0, 2)}) {
                assertx(f[i] < f[j]);
                std::array<int, 2> e{f[i], f[j]};
                auto [iter, ok] = edges_all.insert({e, -1});
                if (ok) {
                    // if this edge is new, we need to assign an index to it
                    assertx(iter->second == -1);
                    iter->second = idx_e++;
                } else {
                    assertx(iter->second >= 0); // it should have "idx_e"
                }
            }
        }

        // sort "edges_all" by "idx_e"
        std::vector<std::array<int, 3>> edges_all_sorted;
        for (const auto &[e, idx_e] : edges_all) {
            edges_all_sorted.push_back({e[0], e[1], idx_e});
        }
        std::sort(edges_all_sorted.begin(), edges_all_sorted.end(),
                  [](const auto &a, const auto &b) { return a[2] < b[2]; });

        // insert edges
        for (const auto &[idx_v0, idx_v1, idx_e] : edges_all_sorted) {
            ss << "Simplex 1 " << idx_e + 1 << " " << idx_v0 + 1 << " " << idx_v1 + 1 << "\n";
        }

        // insert faces
        int idx_f = 0;
        for (const auto &f : faces) {
            assertx(f[0] < f[1] && f[1] < f[2]);
            int idx_e0 = edges_all.at({f[0], f[1]});
            int idx_e1 = edges_all.at({f[1], f[2]});
            int idx_e2 = edges_all.at({f[0], f[2]});
            assertx(idx_e0 >= 0);
            assertx(idx_e1 >= 0);
            assertx(idx_e2 >= 0);
            // for "hh::SimplicialComplex", the indices are to index edges rather than vertices
            ss << "Simplex 2 " << (1 + idx_f++) << " " << idx_e0 + 1 << " " << idx_e1 + 1 << " " << idx_e2 + 1 << "\n";
        }

        // read from string stream
        Kmesh.read(ss);

        // set weighting
        if (!weighting_v.empty()) {
            int size = verts.size();
            assertx(weighting_v.size() == size);
            for (int i = 0; i < size; ++i) {
                Kmesh.getSimplex(0, i + 1)->_weighting_quadric = weighting_v[i];
            }
        }
        if (!weighting_e.empty()) {
            int size = edges.size();
            assertx(weighting_e.size() == size);
            for (int i = 0; i < size; ++i) {
                Kmesh.getSimplex(1, i + 1)->_weighting_quadric = weighting_e[i];
            }
        }
        if (!weighting_f.empty()) {
            int size = faces.size();
            assertx(weighting_f.size() == size);
            for (int i = 0; i < size; ++i) {
                Kmesh.getSimplex(2, i + 1)->_weighting_quadric = weighting_f[i];
            }
        }
    }

    // // // // // // // // // // // // // // // // // // // // // // // // // //
    // // // // // // // // // // // // // // // // // // // // // // // // // //

    // return the number of vertices/edges/faces
    int num(int dim) const { return Kmesh.num(dim); }

    // // // // // // // // // // // // // // // // // // // // // // // // // //
    // // // // // // // // // // // // // // // // // // // // // // // // // //

    // merge two vertices
    void vunify(int vsid, int vtid, const std::string &code, int position_bit, const Array3 &delta_p) {
        hh::SplitRecord vsplit = to_vsplit(vsid, vtid, code, position_bit, delta_p);

        // do unify
        vsplit.applyUnify(Kmesh);
    }

    // split into two vertices
    void gvspl(int vsid, int vtid, const std::string &code, int position_bit, const Array3 &delta_p) {
        hh::SplitRecord vsplit = to_vsplit(vsid, vtid, code, position_bit, delta_p);

        // do split
        vsplit.applySplit(Kmesh);
    }

    // simplify
    std::tuple<std::vector<py::dict>, std::array<float, 3>> simplify() {
        const auto &[pt, op_lst, _] = Kmesh.perform_simplification();
        return std::make_tuple(op_lst, pt);
    }

    // simplify and also return the contraction costs
    std::tuple<std::vector<py::dict>, std::vector<float>, std::array<float, 3>> simplify_with_cost() {
        const auto &[pt, op_lst, cost_lst] = Kmesh.perform_simplification();
        return std::make_tuple(op_lst, cost_lst, pt);
    }

    // // // // // // // // // // // // // // // // // // // // // // // // // //
    // // // // // // // // // // // // // // // // // // // // // // // // // //

    // write into ".sc" file for "G3dOGL" visualization
    void write(std::string filepath) const {

        // set "vattr", otherwise there will be an error writing the file
        for_int(dim, 3) { // 0, 1, 2
            for (hh::Simplex s : Kmesh.ordered_simplices_dim(dim)) {
                if (s->isPrincipal()) {
                    s->setVAttribute(0);
                }
            }
        }

        std::ofstream ofs(filepath);
        if (!ofs) {
            std::cerr << "cannot open: " << filepath << std::endl;
            return;
        }

        Kmesh.write(ofs);
        ofs.close();
    }

    // return the simplicial complex's positions and indices
    //   NOTE : i-th row indicates the simplex has index "i", with i>=0
    auto write() const {
        std::vector<std::array<float, 3>> verts;
        std::vector<std::array<int, 2>> edges;
        std::vector<std::array<int, 3>> faces;

        for (int dim : {0, 1, 2}) {                           // for each dimension
            for (auto s : Kmesh.ordered_simplices_dim(dim)) { // for each simplex

                if (dim == 0) { // for each vertex
                    auto p = s->getPosition();
                    verts.push_back({p[0], p[1], p[2]});

                } else { // not a point
                    auto [v0, v1, v2] = hh::compute_defining_vertex_ids(s);
                    if (dim == 1) { // edge
                        edges.push_back({v0 - 1, v1 - 1});
                    } else { // face
                        faces.push_back({v0 - 1, v1 - 1, v2 - 1});
                    }
                }
            }
        }
        return std::make_tuple(verts, edges, faces);
    }

    // // // // // // // // // // // // // // // // // // // // // // // // // //
    // // // // // // // // // // // // // // // // // // // // // // // // // //

    // get simplices of adjacent edges and faces
    auto get_star(int vsid) const {

        std::vector<std::array<int, 2>> edges;
        std::vector<std::array<int, 3>> faces;

        // assume "vsid" starts from zero
        hh::Simplex vs = assertx(Kmesh.getSimplex(0, vsid + 1));
        hh::Pqueue<hh::Simplex> pq[hh::ISimplex::MAX_DIM + 1];
        for (hh::Simplex spx : vs->get_star()) {
            pq[spx->getDim()].enter_unsorted(spx, float(spx->getId()));
        }

        // for each edge/face
        for (int dim : {1, 2}) {
            pq[dim].sort();
            while (!pq[dim].empty()) {
                hh::Simplex s = pq[dim].remove_min();

                // get the indices of its extreme points
                auto [v0, v1, v2] = hh::compute_defining_vertex_ids(s);

                // save indices
                if (dim == 1) {
                    edges.push_back({v0 - 1, v1 - 1});
                } else {
                    faces.push_back({v0 - 1, v1 - 1, v2 - 1});
                }
            }
        }

        return std::make_tuple(edges, faces);
    }

private:
    // // // // // // // // // // // // // // // // // // // // // // // // // //
    // // // // // // // // // // // // // // // // // // // // // // // // // //

    // build a "SplitRecord" object
    hh::SplitRecord to_vsplit(int vsid, int vtid, const std::string &code, int position_bit,
                              const Array3 &delta_p) const {
        // to a string
        std::stringstream ss;

        // assume "vsid" and "vtid" start from zero
        ss << vsid + 1 << " " << vtid + 1 << "\n";
        ss << code << "\n";
        ss << position_bit << " " << delta_p[0] << " " << delta_p[1] << " " << delta_p[2] << "\n";
        ss << "-1\n-1\n";

        // to "vsplit"
        hh::SplitRecord vsplit;
        vsplit.read(ss);
        return vsplit;
    }
};

// // // // // // // // // // // // // // // // // // // // // // // // // //
// // // // // // // // // // // // // // // // // // // // // // // // // //

PYBIND11_MODULE(_core, m) {
    m.doc() = "Progressive Simplicial Complexes";

    py::class_<PSC>(m, "PSC")
        .def(py::init<const Array3 &>(), py::arg("init_p"))
        .def(py::init<std::vector<std::array<float, 3>>, std::vector<std::array<int, 2>>,
                      std::vector<std::array<int, 3>>, std::vector<float>, std::vector<float>, std::vector<float>,
                      float>(),
             py::arg("verts"), py::arg("edges"), py::arg("faces"), py::arg("weighting_v") = std::vector<float>{},
             py::arg("weighting_e") = std::vector<float>{}, py::arg("weighting_f") = std::vector<float>{},
             py::arg("weighting_topo") = 1.0f)
        .def("num", &PSC::num, py::arg("dim"))
        .def("vunify", &PSC::vunify, py::arg("vsid"), py::arg("vtid"), py::arg("code"), py::arg("position_bit"),
             py::arg("delta_p"))
        .def("gvspl", &PSC::gvspl, py::arg("vsid"), py::arg("vtid"), py::arg("code"), py::arg("position_bit"),
             py::arg("delta_p"))
        .def("write", py::overload_cast<std::string>(&PSC::write, py::const_), py::arg("filepath"))
        .def("write", py::overload_cast<>(&PSC::write, py::const_))
        .def("get_star", &PSC::get_star, py::arg("vsid"))
        .def("simplify", &PSC::simplify)
        .def("simplify_with_cost", &PSC::simplify_with_cost);

    py::class_<Voxelizer>(m, "Voxelizer")
        .def(py::init<double, int>(), py::arg("voxel_size") = 0.01, py::arg("parallel_threshold") = 10000)
        .def("voxelize",
             py::overload_cast<const std::vector<std::array<typename Voxelizer::Vec3d, 3>> &, const std::vector<int> &>(
                 &Voxelizer::voxelize),
             py::arg("triangles"), py::arg("indices"))
        .def("voxelize",
             py::overload_cast<const std::vector<std::array<typename Voxelizer::Vec3d, 2>> &, const std::vector<int> &>(
                 &Voxelizer::voxelize),
             py::arg("lines"), py::arg("indices"))
        .def("voxelize",
             py::overload_cast<const std::vector<typename Voxelizer::Vec3d> &, const std::vector<int> &>(
                 &Voxelizer::voxelize),
             py::arg("points"), py::arg("indices"))
        .def("read", &Voxelizer::read)
        .def("clear", &Voxelizer::clear);
}
