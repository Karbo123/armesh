import os, sys
import shutil
import platform
import pybind11
import sysconfig
import os.path as osp
from glob import glob
from setuptools import setup, find_packages
from pybind11.setup_helpers import (
    Pybind11Extension,
    ParallelCompile,
    build_ext as pybind11_build_ext,
)


def find_vcpkg_root():
    vcpkg_executable = shutil.which("vcpkg")
    if not vcpkg_executable:
        raise FileNotFoundError("vcpkg executable not found in PATH.")
    vcpkg_root = osp.dirname(vcpkg_executable)
    return vcpkg_root


def glob_cpp(name):
    return glob(f"third_party/Mesh-processing-library/{name}/*.cpp")


# whether on Windows
is_win = platform.system() == "Windows"

# we may only build the executable under the python 3.10 environment
is_py310 = (sys.version_info.major, sys.version_info.minor) == (3, 10)

# get the name of executable
exe_name = "G3dOGL"  # without suffix
exe_suffix = ".exe" if is_win else ""


# build executable
class BuildExtWithExe(pybind11_build_ext):
    def run(self):
        # run the original build_ext（for compiling .so / .pyd）
        super().run()

        # build the exe
        self.build_g3dogl_exe()

    def build_g3dogl_exe(self):

        ParallelCompile("NPY_NUM_BUILD_JOBS").install()

        # source files
        sources = (
            glob_cpp("G3dOGL")
            + glob_cpp("libHh")
            + (glob_cpp("libHwWindows") if is_win else glob_cpp("libHwX"))
        )

        # include folders
        include_dirs = [
            "src",
            "third_party/Mesh-processing-library",
            "third_party/Mesh-processing-library/"
            + ("libHwWindows" if is_win else "libHwX"),
            pybind11.get_include(),
        ]
        if is_win:
            vcpkg_root = find_vcpkg_root()
            include_dirs.append(
                osp.join(vcpkg_root, "installed", "x64-windows", "include")
            )

        library_dirs = []
        libraries = []
        extra_link_args = []
        extra_compile_args = []

        if is_win:
            vcpkg_root = find_vcpkg_root()
            library_dirs.append(osp.join(vcpkg_root, "installed", "x64-windows", "lib"))
            libraries = ["advapi32", "user32", "gdi32", "qhullcpp", "qhull_r", "tbb12"]
            extra_compile_args = ["/EHsc", "/std:c++20", "/openmp"]
            extra_link_args = ["/openmp"]
        else:
            library_dirs.append(sysconfig.get_config_var("LIBDIR"))
            libraries = [
                "GL",
                "GLU",
                "png",
                "jpeg",
                "qhullcpp",
                "qhull_r",
                "tbb",
                "X11",
                "Xext",
            ]
            libraries += ["stdc++", "m"]
            extra_compile_args = ["-std=c++20", "-fopenmp"]
            extra_link_args = ["-fopenmp"]

        # the exe output folder
        build_temp = osp.abspath(self.build_temp)
        os.makedirs(build_temp, exist_ok=True)
        output_path = osp.join(build_temp, exe_name)

        # the compiler, and temp obj files
        compiler = self.compiler
        objects = []

        # for each source file
        for src in sources:
            obj = compiler.compile(
                [src],
                output_dir=build_temp,
                include_dirs=include_dirs,
                extra_preargs=extra_compile_args,
                debug=self.debug,
            )
            objects.extend(obj)

        # link and form the final executable
        compiler.link_executable(
            objects,
            output_progname=osp.basename(output_path),
            output_dir=osp.dirname(output_path),
            libraries=libraries,
            library_dirs=library_dirs,
            extra_preargs=extra_link_args,
            debug=self.debug,
        )

        # with extension suffix
        output_path += exe_suffix
        print(f"Built executable: {output_path}")

        # copy to the root of the project
        out_folder = os.getcwd() if is_win else "/output"
        os.makedirs(out_folder, exist_ok=True)
        final_exe = osp.join(out_folder, exe_name + exe_suffix)
        shutil.copy2(output_path, final_exe)
        print(f"Copied to: {final_exe}")


# compile the library
ext_modules = [
    Pybind11Extension(
        "libpsc._core",
        sources=[
            "src/main.cpp",
            *glob_cpp("G3dOGL"),
            *glob_cpp("libHh"),
            *glob_cpp("libHwWindows" if is_win else "libHwX"),
        ],
        include_dirs=[
            "src",
            "third_party/Mesh-processing-library",
            "third_party/Mesh-processing-library/"
            + ("libHwWindows" if is_win else "libHwX"),
            *(
                [osp.join(find_vcpkg_root(), "installed", "x64-windows", "include")]
                if is_win
                else []
            ),
        ],
        library_dirs=[
            *(
                [osp.join(find_vcpkg_root(), "installed", "x64-windows", "lib")]
                if is_win
                else []
            ),
        ],
        extra_compile_args=(
            ["/EHsc", "/std:c++20", "/DBUILD_LIBPSC", "/openmp"]
            if is_win
            else ["-std=c++20", "-DBUILD_LIBPSC", "-fopenmp"]
        ),
        libraries=(
            ["advapi32", "user32", "gdi32", "qhullcpp", "qhull_r", "tbb12"]
            if is_win
            else ["GL", "GLU", "png", "jpeg", "qhullcpp", "qhull_r", "tbb"]
        ),
    )
]

setup(
    name="libpsc",
    version="0.2",
    ext_modules=ext_modules,
    packages=find_packages(),
    package_data={
        "libpsc": ["*.so", "*.dll", "*.pyd"],
    },
    zip_safe=False,
    **(
        dict(cmdclass={"build_ext": BuildExtWithExe}) if is_py310 else dict()
    ),  # build exe
)
