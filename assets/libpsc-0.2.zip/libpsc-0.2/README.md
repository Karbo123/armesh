# libpsc: a library for progressive simplicial complex

## raw APIs

import all necessary names
```python
import numpy as np
from libpsc import *
```

initialize the starting location for progressive simplicial complex
```python
psc = PSC([0.0, 0.0, 0.0])
```

build a progressive simplicial complex from reversing simplification
```python
num_v, num_e, num_f = 100, 150, 200
create_fn = lambda n, d: np.unique(np.sort(np.random.randint(n * 2, size=(num_e, d)), axis=1), axis=0)[:n]

verts = np.random.randn(num_v, 3)
edges = create_fn(num_e, 2)
faces = create_fn(num_f, 3)

psc = PSC(verts, edges, faces, weighting_v, weighting_e, weighting_f, weighting_topo)
```


## advanced APIs




