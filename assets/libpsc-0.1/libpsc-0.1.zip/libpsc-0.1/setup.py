import shutil
import platform
import os.path as osp
from glob import glob
from setuptools import setup, find_packages
from pybind11.setup_helpers import Pybind11Extension


def find_vcpkg_root():
    vcpkg_executable = shutil.which("vcpkg")
    if not vcpkg_executable:
        raise FileNotFoundError("vcpkg executable not found in PATH.")
    vcpkg_root = osp.dirname(vcpkg_executable)
    return vcpkg_root


def glob_cpp(name):
    return glob(f"third_party/Mesh-processing-library/{name}/*.cpp")


is_win = platform.system() == "Windows"

ext_modules = [
    Pybind11Extension(
        "libpsc._core",
        sources=[
            "src/main.cpp",
            *glob_cpp("G3dOGL"),
            *glob_cpp("libHh"),
            *glob_cpp("libHwWindows" if is_win else "libHwX"),
        ],
        include_dirs=[
            "src",
            "third_party/Mesh-processing-library",
            "third_party/Mesh-processing-library/"
            + ("libHwWindows" if is_win else "libHwX"),
            *(
                [osp.join(find_vcpkg_root(), "installed", "x64-windows", "include")]
                if is_win
                else []
            ),
        ],
        library_dirs=[
            *(
                [osp.join(find_vcpkg_root(), "installed", "x64-windows", "lib")]
                if is_win
                else []
            ),
        ],
        extra_compile_args=(
            ["/EHsc", "/std:c++20", "/DBUILD_LIBPSC", "/openmp"]
            if is_win
            else ["-std=c++20", "-DBUILD_LIBPSC", "-fopenmp"]
        ),
        libraries=(
            ["advapi32", "user32", "gdi32", "qhullcpp", "qhull_r", "tbb12"]
            if is_win
            else ["GL", "GLU", "png", "jpeg", "qhullcpp", "qhull_r", "tbb"]
        ),
    )
]

setup(
    name="libpsc",
    version="0.1",
    ext_modules=ext_modules,
    packages=find_packages(),
    package_data={
        "libpsc": ["*.so", "*.dll", "*.pyd"],
    },
    zip_safe=False,
)
